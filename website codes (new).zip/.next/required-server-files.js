self.__SERVER_FILES_MANIFEST={
  "version": 1,
  "config": {
    "distDir": ".next",
    "cacheComponents": false,
    "htmlLimitedBots": "[\\w-]+-Google|Google-[\\w-]+|Chrome-Lighthouse|Slurp|DuckDuckBot|baiduspider|yandex|sogou|bitlybot|tumblr|vkShare|quora link preview|redditbot|ia_archiver|Bingbot|BingPreview|applebot|facebookexternalhit|facebookcatalog|Twitterbot|LinkedInBot|Slackbot|Discordbot|WhatsApp|SkypeUriPreview|Yeti|googleweblight",
    "assetPrefix": "",
    "trailingSlash": false,
    "images": {
      "deviceSizes": [
        640,
        750,
        828,
        1080,
        1200,
        1920,
        2048,
        3840
      ],
      "imageSizes": [
        32,
        48,
        64,
        96,
        128,
        256,
        384
      ],
      "path": "/_next/image",
      "loader": "default",
      "loaderFile": "",
      "domains": [],
      "disableStaticImages": false,
      "minimumCacheTTL": 14400,
      "formats": [
        "image/webp"
      ],
      "maximumRedirects": 3,
      "dangerouslyAllowLocalIP": false,
      "dangerouslyAllowSVG": false,
      "contentSecurityPolicy": "script-src 'none'; frame-src 'none'; sandbox;",
      "contentDispositionType": "attachment",
      "localPatterns": [
        {
          "pathname": "**",
          "search": ""
        }
      ],
      "remotePatterns": [],
      "qualities": [
        75
      ],
      "unoptimized": false
    },
    "reactMaxHeadersLength": 6000,
    "cacheLife": {
      "default": {
        "stale": 300,
        "revalidate": 900,
        "expire": 4294967294
      },
      "seconds": {
        "stale": 30,
        "revalidate": 1,
        "expire": 60
      },
      "minutes": {
        "stale": 300,
        "revalidate": 60,
        "expire": 3600
      },
      "hours": {
        "stale": 300,
        "revalidate": 3600,
        "expire": 86400
      },
      "days": {
        "stale": 300,
        "revalidate": 86400,
        "expire": 604800
      },
      "weeks": {
        "stale": 300,
        "revalidate": 604800,
        "expire": 2592000
      },
      "max": {
        "stale": 300,
        "revalidate": 2592000,
        "expire": 31536000
      }
    },
    "basePath": "",
    "expireTime": 31536000,
    "generateEtags": true,
    "poweredByHeader": true,
    "cacheHandlers": {},
    "cacheMaxMemorySize": 52428800,
    "compress": true,
    "i18n": null,
    "httpAgentOptions": {
      "keepAlive": true
    },
    "pageExtensions": [
      "tsx",
      "ts",
      "jsx",
      "js"
    ],
    "useFileSystemPublicRoutes": true,
    "experimental": {
      "ppr": false,
      "staleTimes": {
        "dynamic": 0,
        "static": 300
      },
      "dynamicOnHover": false,
      "inlineCss": false,
      "authInterrupts": false,
      "fetchCacheKeyPrefix": "",
      "isrFlushToDisk": true,
      "optimizeCss": false,
      "nextScriptWorkers": false,
      "disableOptimizedLoading": false,
      "largePageDataBytes": 128000,
      "serverComponentsHmrCache": true,
      "caseSensitiveRoutes": false,
      "validateRSCRequestHeaders": false,
      "useSkewCookie": false,
      "preloadEntriesOnStart": true,
      "hideLogsAfterAbort": false,
      "removeUncaughtErrorAndRejectionListeners": false,
      "imgOptConcurrency": null,
      "imgOptMaxInputPixels": 268402689,
      "imgOptSequentialRead": null,
      "imgOptSkipMetadata": null,
      "imgOptTimeoutInSeconds": 7,
      "proxyClientMaxBodySize": 10485760,
      "trustHostHeader": false,
      "isExperimentalCompile": false
    }
  },
  "appDir": "C:\\Users\\Bivaas\\Desktop\\Booklyx",
  "relativeAppDir": "",
  "files": [
    ".next\\routes-manifest.json",
    ".next\\server\\pages-manifest.json",
    ".next\\build-manifest.json",
    ".next\\prerender-manifest.json",
    ".next\\server\\functions-config-manifest.json",
    ".next\\server\\middleware-manifest.json",
    ".next\\server\\middleware-build-manifest.js",
    ".next\\server\\app-paths-manifest.json",
    ".next\\app-path-routes-manifest.json",
    ".next\\server\\server-reference-manifest.js",
    ".next\\server\\server-reference-manifest.json",
    ".next\\BUILD_ID",
    ".next\\server\\next-font-manifest.js",
    ".next\\server\\next-font-manifest.json",
    ".next\\required-server-files.json"
  ],
  "ignore": []
}