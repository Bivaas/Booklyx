var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/availability/route.js")
R.c("server/chunks/[root-of-the-server]__483bb887._.js")
R.c("server/chunks/[root-of-the-server]__38e43404._.js")
R.c("server/chunks/[root-of-the-server]__e26c8107._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_availability_route_actions_d5ea7375.js")
R.m(39005)
module.exports=R.m(39005).exports
