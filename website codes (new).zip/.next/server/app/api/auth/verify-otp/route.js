var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/verify-otp/route.js")
R.c("server/chunks/[root-of-the-server]__d8cad448._.js")
R.c("server/chunks/[root-of-the-server]__38e43404._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__e26c8107._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_verify-otp_route_actions_d8cf5ff0.js")
R.m(80569)
module.exports=R.m(80569).exports
