var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/signup/route.js")
R.c("server/chunks/[root-of-the-server]__6aa8ef58._.js")
R.c("server/chunks/[root-of-the-server]__38e43404._.js")
R.c("server/chunks/[root-of-the-server]__e26c8107._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_signup_route_actions_3cc2654d.js")
R.m(72394)
module.exports=R.m(72394).exports
