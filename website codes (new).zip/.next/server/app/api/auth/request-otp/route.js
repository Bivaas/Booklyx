var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/request-otp/route.js")
R.c("server/chunks/[root-of-the-server]__76b37656._.js")
R.c("server/chunks/[root-of-the-server]__38e43404._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__e26c8107._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_request-otp_route_actions_42329431.js")
R.m(36883)
module.exports=R.m(36883).exports
