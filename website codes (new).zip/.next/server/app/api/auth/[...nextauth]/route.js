var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__5e9fd839._.js")
R.c("server/chunks/node_modules_bcryptjs_index_42ebb250.js")
R.c("server/chunks/[root-of-the-server]__e26c8107._.js")
R.c("server/chunks/[root-of-the-server]__1faa8561._.js")
R.c("server/chunks/[root-of-the-server]__38e43404._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_[___nextauth]_route_actions_1c865db8.js")
R.m(3413)
module.exports=R.m(3413).exports
