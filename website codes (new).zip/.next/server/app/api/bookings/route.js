var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/bookings/route.js")
R.c("server/chunks/[root-of-the-server]__2475c41b._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_6ef62dd8.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__e26c8107._.js")
R.c("server/chunks/[root-of-the-server]__38e43404._.js")
R.c("server/chunks/_next-internal_server_app_api_bookings_route_actions_eb288a0b.js")
R.m(35578)
module.exports=R.m(35578).exports
