var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bookings/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__88616c4c._.js")
R.c("server/chunks/[root-of-the-server]__38e43404._.js")
R.c("server/chunks/[root-of-the-server]__e26c8107._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_bookings_[id]_route_actions_b6e76d8c.js")
R.m(15899)
module.exports=R.m(15899).exports
