var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/otp/verify/route.js")
R.c("server/chunks/[root-of-the-server]__e24c24f6._.js")
R.c("server/chunks/[root-of-the-server]__38e43404._.js")
R.c("server/chunks/[root-of-the-server]__e26c8107._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_otp_verify_route_actions_37c798ec.js")
R.m(56633)
module.exports=R.m(56633).exports
