var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/otp/request/route.js")
R.c("server/chunks/[root-of-the-server]__a1775d14._.js")
R.c("server/chunks/[root-of-the-server]__38e43404._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__e26c8107._.js")
R.c("server/chunks/_next-internal_server_app_api_otp_request_route_actions_897c7618.js")
R.m(60338)
module.exports=R.m(60338).exports
