1:"$Sreact.fragment"
2:I[92825,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"ClientSegmentRoot"]
3:I[39126,["/_next/static/chunks/18363e0d7212ffb7.js","/_next/static/chunks/867f43ad00c8c71a.js","/_next/static/chunks/5fd0bce132040e3b.js","/_next/static/chunks/195c216f52dae3f8.js"],"default"]
4:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
5:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
0:{"buildId":"8k9L2_aJka46XQgc_-izC","rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/867f43ad00c8c71a.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/5fd0bce132040e3b.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/195c216f52dae3f8.js","async":true}]],["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"loading":null,"isPartial":false}
6:"$0:rsc:props:children:1:props:serverProvidedParams:params"
