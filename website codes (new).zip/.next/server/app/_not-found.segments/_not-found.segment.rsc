1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/f4c97a040466df63.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
3:I[37457,["/_next/static/chunks/f4c97a040466df63.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
0:{"buildId":"8k9L2_aJka46XQgc_-izC","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
