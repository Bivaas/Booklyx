module.exports=[6109,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_business-approval_route_actions_df9facde.js.map