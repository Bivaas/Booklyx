module.exports=[89578,a=>{a.v({className:"geist_a71539c9-module__T19VSG__className",variable:"geist_a71539c9-module__T19VSG__variable"})},35214,a=>{a.v({className:"geist_mono_8d43a2aa-module__8Li5zG__className",variable:"geist_mono_8d43a2aa-module__8Li5zG__variable"})},23115,a=>{"use strict";a.s(["Providers",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call Providers() from the server but Providers is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/app/providers.tsx <module evaluation>","Providers")},36459,a=>{"use strict";a.s(["Providers",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call Providers() from the server but Providers is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/app/providers.tsx","Providers")},62752,a=>{"use strict";a.i(23115);var b=a.i(36459);a.n(b)},27572,a=>{"use strict";var b=a.i(7997),c=a.i(89578);let d={className:c.default.className,style:{fontFamily:"'Geist', 'Geist Fallback'",fontStyle:"normal"}};null!=c.default.variable&&(d.variable=c.default.variable);var e=a.i(35214);let f={className:e.default.className,style:{fontFamily:"'Geist Mono', 'Geist Mono Fallback'",fontStyle:"normal"}};function g(){let a=`
    (function() {
      const theme = localStorage.getItem('theme');
      const root = document.documentElement;
      
      if (theme === 'dark') {
        root.classList.add('dark');
      } else if (theme === 'light') {
        root.classList.add('light');
      } else {
        // Default to system preference
        const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        root.classList.add(systemTheme);
      }
    })();
  `;return(0,b.jsx)("script",{dangerouslySetInnerHTML:{__html:a}})}null!=e.default.variable&&(f.variable=e.default.variable);var h=a.i(62752);function i({children:a}){return(0,b.jsxs)("html",{lang:"en",suppressHydrationWarning:!0,children:[(0,b.jsxs)("head",{children:[(0,b.jsx)(g,{}),(0,b.jsx)("link",{rel:"icon",type:"image/svg+xml",href:"/favicon.svg"})]}),(0,b.jsx)("body",{className:`${d.variable} ${f.variable} antialiased`,children:(0,b.jsx)(h.Providers,{children:a})})]})}a.s(["default",()=>i,"metadata",0,{title:"Booklyx - Booking System",description:"Manage bookings and schedules for your business"}],27572)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__9a619a34._.js.map