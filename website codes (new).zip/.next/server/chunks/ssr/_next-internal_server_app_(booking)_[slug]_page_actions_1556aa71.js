module.exports=[51403,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28booking%29_%5Bslug%5D_page_actions_1556aa71.js.map