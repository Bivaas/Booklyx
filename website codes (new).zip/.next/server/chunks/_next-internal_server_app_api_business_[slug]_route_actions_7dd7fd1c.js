module.exports=[45989,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_business_%5Bslug%5D_route_actions_7dd7fd1c.js.map